CREATE DATABASE IF NOT EXISTS `pricepoint`;

USE `pricepoint`;

DROP TABLE IF EXISTS `customerinvoice`;

CREATE TABLE `customerinvoice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer` text NOT NULL,
  `date` text NOT NULL,
  `invno` text NOT NULL,
  `totalamt` int(11) NOT NULL,
  `totalpaid` int(11) NOT NULL,
  `outbalance` int(11) NOT NULL,
  `category` text NOT NULL,
  `salesref` text NOT NULL,
  `paymeth` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `customerinvoice` VALUES ("1","JAYBISCO PHARMACY","2018-09-06","ST101165293","129420","129420","0","visitor","ugo","Cash"),
("2","GOD\'S CARE PHARMACY","2018-09-06","PP00002","56960","56960","0","visitor","ugo","Cash"),
("3","LOVIFO PHARMACY","2018-09-06","PP00003","25080","25080","0","visitor","ugo","Cash"),
("4","ewere","2018-09-29","PP00004","2520","0","2520","customer","pricepoint","Credit");



DROP TABLE IF EXISTS `customers`;

CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_name` text NOT NULL,
  `customer_email` text NOT NULL,
  `customer_phone` text NOT NULL,
  `address` text NOT NULL,
  `account_created_on` text NOT NULL,
  `last_visit` text NOT NULL,
  `visit_count` int(11) NOT NULL,
  `outstanding_balance` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `customers` VALUES ("1","ewere","","","","2018-09-29","2018-09-29","1","2520");



DROP TABLE IF EXISTS `invoice`;

CREATE TABLE `invoice` (
  `id` int(11) NOT NULL,
  `inv` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `invoice` VALUES ("1","5");



DROP TABLE IF EXISTS `products`;

CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` text NOT NULL,
  `product_description` text NOT NULL,
  `stock` int(11) NOT NULL,
  `product_retailprice` int(11) NOT NULL,
  `product_wholesaleprice` int(11) NOT NULL,
  `expiry_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=latin1;

INSERT INTO `products` VALUES ("1","EMZOR paracetamol Tab By 96","Paracetamol Tablet 500mg","20","250","210","2018-09-30"),
("2","AMPICLOX Caps Beecham 500mg","AMPICILLIN 250mg/CLOXACILLIN 250mg Caps","0","6500","5995","0000-00-00"),
("3","Augumentin Tab 625mg","Amoxycillin 500mg/Clavulanate 125mg Tab","0","2800","2685","0000-00-00"),
("4","Ciprotab Tab 500mg By 10","Ciprofloxacin 500mg Tablet","0","1000","880","0000-00-00"),
("5","Talen Tab 1.5mg","Bromazepam Tablet 1.5mg","0","600","420","0000-00-00"),
("6","TALEN 3mg","Bromazepam 3mg","0","800","630","0000-00-00"),
("7","AUGUMENTIN TAB 1g","Amoxycillin 875mg/Clavulanic acid 125mg","0","3200","3065","0000-00-00"),
("8","AUGUMENTIN TAB 375mg","Amoxycillin 250mg/Clavulanic Acid 125mg","0","2300","2105","0000-00-00"),
("9","AUGUMENTIN SYRUP 228","Amoxycillin 200mg/Clavulanic Acid 28.5mg","0","1700","1580","0000-00-00"),
("10","AUGUMENTIN ES SYRUP","Amoxycillin Trihydrate/Potassium Clavulanate","0","3200","2900","0000-00-00"),
("11","AMOXIL CAPS 500mg 10 x 10","Amoxycillin 500mg Caps","0","5000","4035","0000-00-00"),
("12","AMOXIL CAPS 250mg 10 x10","Amoxycillin 250mg Caps","0","2000","1805","0000-00-00"),
("13","AMOXIL SYRUP 125mg/5ml","Amoxycillin 125mg/5ml","0","700","625","0000-00-00"),
("14","AMPICLOX SYRUP 250mg/5ml","Ampicillin 125mg/Cloxacillin 125mg","0","1200","1065","0000-00-00"),
("15","AMPICLOX DROP 90mg/0.6ml","Ampicillin 60mg/Cloxacillin 30mg","0","800","625","0000-00-00"),
("16","ZINNAT TAB 500mg","Cefuroxime Tab 500mg","0","3000","2765","0000-00-00"),
("17","ZINNAT TAB 250mg","Cefuroxime Tab 250mg","0","2200","1915","0000-00-00"),
("18","ZINNAT SYRUP 50ml","Cefuroxime 125mg/5ml","0","2500","2150","0000-00-00"),
("19","VENTOLIN INHALER","Salbutamol 100micrograms","0","1000","1150","0000-00-00"),
("20","FORTUM Inj 1g","Ceftazidime 1g","0","2500","2330","0000-00-00"),
("21","Ciprotab Tab by 14","Ciprofloxacin 500mg Tab","0","1250","1140","0000-00-00"),
("22","ASTYMIN SYRUP 200ml","Multivitamins/Amino acids Syrup","0","1150","1080","0000-00-00"),
("23","ASTYMIN CAPS 2 X 10","Mutivitamins/Amino acids","0","1200","1080","0000-00-00"),
("24","ASTYFER SYRUP 200ml","Multivitamins/Amino acids/Iron","0","1200","1080","0000-00-00"),
("25","ASTYFER CAPS 2 X 15","Multivitamins/Amino acids/Iron","0","1200","1080","0000-00-00"),
("26","TRIBOTAN BABY CREAM","Baby Cream 20g","0","450","395","0000-00-00"),
("27","SWIDAR TAB","Sulfadoxine 500mg/Pyrimethamin 25mg","0","250","198","0000-00-00"),
("28","CLABETIC TAB","Glibenclamide 5mg/Metformin 500mg","0","700","630","0000-00-00"),
("29","TINIFLOX TAB x10","Ofloxacin 200mg/Tinidazole 600mg","0","800","550","0000-00-00"),
("30","TINIFLOX TAB X20","Ofloxacin 200mg/Tinidazole 600mg","0","1500","990","0000-00-00"),
("31","UNIVAL TAB 5mg 2 x 6","Diazepam 5mg","0","400","315","0000-00-00"),
("32","UNIVAL TAB 5mg 16 x 6","Diazepam 5mg","0","2400","1890","0000-00-00"),
("33","EMZOR Paracetamol Syrup 60ml","Paracetamol Syr 125mg/5ml","0","150","106","0000-00-00"),
("34","Em-Vit-C SYRUP 100ml","Vitamin C Syrup","0","200","154","0000-00-00"),
("35","EMVITE SYRUP 100ml","Multivitamin Syrup","0","250","161","0000-00-00"),
("36","EMZOLYN CHILD","Cough Syrup","0","180","156","0000-00-00"),
("37","EMZOLYN ADULT","Cough Syrup","0","190","169","0000-00-00"),
("38","EMMOX SUSPENSION","Amoxicillin 125mg/5ml","0","230","206","0000-00-00"),
("39","EMZOCLOX SUSPENSION","Ampicillin 125mg/Cloxacillin 125mg","0","280","259","0000-00-00"),
("40","ZOLAT SUSPENSION","Albendazole 200mg Susp.","0","150","105","0000-00-00"),
("41","MALDOX TAB 1 x 3","Sulfadoxine 500mg/Pyrimethamine 25mg","0","100","90","0000-00-00"),
("42","EM-VIT-C TAB (W) BY 1000","Vitamin C Tab (W) BY 1000","0","780","725","0000-00-00"),
("43","Em-Vit-C TAB (C) BY 1000","Vitamin C Tab (C) BY 1000","76","800","755","2018-09-20"),
("44","Em-Vit-C TAB (W) BY 100","Vutamin C Tab (W) BY 100","0","250","175","0000-00-00"),
("45","Em-Vit-C TAB (C) BY 100","Vitamin C Tab (C) BY 100","0","250","205","0000-00-00"),
("46","EMTRIM TAB (Blister) 10 X 100","Co-Trimoxazole 480mg","0","4450","4380","0000-00-00"),
("47","EMTRIM SYRUP 50ml","Co-Trimoxazole Susp 240mg/5ml","0","200","145","0000-00-00"),
("48","EMCAP SUSPENSION 100ml","Paracetamol Susp 125mg/5ml","0","200","135","0000-00-00"),
("49","Em-B-Plex SYRUP 100ml","Vitamin B-Complex Syr","0","200","140","0000-00-00"),
("50","Folic Acid Tab BY 100","Folic Acid Tab 5mg","0","200","130","0000-00-00"),
("51","AUGUMENTIN SYRUP 457mg/5ml","Amoxycillin 400mg/Clavulanate 57mg","0","2700","2480","0000-00-00"),
("52","ACCU-CHEK ACTIVE KIT","MACHINE (KIT)\nmg/dl","0","6000","5800","0000-00-00"),
("53","ACCU-CHEK ACTIVE","50 STRIPS","0","4500","4200","0000-00-00"),
("54","OMRON M2","BP MONITOR (M2)","0","15000","13500","0000-00-00"),
("55","OMRON M3","BP MONITOR (M3)","0","21000","19500","0000-00-00"),
("56","OMRON M6","BP MONITOR (M6)","0","27000","24500","0000-00-00"),
("57","OMRON IQ142","BP MONITOR (IQ 142)","0","72000","69000","0000-00-00"),
("58","CIPROTAB TN X10","","0","0","1060","0000-00-00"),
("59","AUGUMENTIN DROPS","Amoxicillin trihydrate-Potassium clavulanate","0","0","740","0000-00-00"),
("60","COARTEM TAB 80/480","1 X 6Tab","0","1500","1270","0000-00-00"),
("61","COARTEM TAB 20/120","4 X 6Tab","0","1200","950","0000-00-00"),
("62","COARTEM TAB 20/120 (3 X 6Tab)","3 x 6Tab","0","690","1000","0000-00-00"),
("63","COARTEM TAB 20/120 (2 X 6Tab)","2 x 6Tab","0","800","590","0000-00-00"),
("64","COARTEM TAB 20/120 (1 X 6Tab)","1 x 6Tab","0","600","480","0000-00-00"),
("65","LONART DS TAB","1 X 6Tab","0","1200","880","0000-00-00"),
("66","LONART 20/120 TAB","4 X 6Tab","0","600","330","0000-00-00"),
("67","LONART 20/120 DISPERSIBLE TAB","1 X 6Tab","0","300","170","0000-00-00"),
("68","LONART SYRUP","60ml","0","1000","680","0000-00-00"),
("69","MYCOTEN CREAM","20g Tube","0","300","265","0000-00-00"),
("70","MYCOTEN VAG. CREAM","35g Tube","0","800","530","0000-00-00"),
("71","MYCOTEN VAG. TAB","1 X 6Tab","0","800","520","0000-00-00"),
("72","BIOCOTEN CREAM","20g Tube","0","400","310","0000-00-00"),
("73","NEUROGESIC OINTMENT S/S","35g Tube","0","500","385","0000-00-00"),
("74","NEUROGESIC OINTMENT B/S","85g Tube","0","800","610","0000-00-00"),
("75","ZINNAT INJECTION","750mg Vial","0","4800","4400","0000-00-00"),
("76","MALDOX SUSPENSION 15ml","Sulfadoxine 500mg/Pyrimethamine 25mg (5ml)","0","200","160","0000-00-00"),
("77","EMGYL SYRUP 60ml","Metronidazole 200mg/5ml","0","200","148","0000-00-00"),
("78","ZOLAT CAPLET 200mg x 2.","Albendazole 200mg","0","100","68","0000-00-00"),
("79","Em-B-Plex Tablet x 100","Vitamin B-Complex Tablet","0","200","90","0000-00-00"),
("80","Em-B-Plex Tablet x 1000","Vitamin B-Complex","0","600","480","0000-00-00"),
("81","Em-Vit-C DROPS 15ml","Vitamin C Drops","0","200","148","0000-00-00"),
("82","EMZOR PARA 1000","Paracetamol 1000mg Caplet ","0","2300","2200","0000-00-00"),
("83","FOLIC ACID TABLET X 1000","Folic Acid Tablet 5mg","0","1000","940","0000-00-00"),
("84","EMZOR paracetamol DROP","","0","0","130","0000-00-00");



DROP TABLE IF EXISTS `sales`;

CREATE TABLE `sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoiceno` text NOT NULL,
  `customer_name` text NOT NULL,
  `product` text NOT NULL,
  `quantity` int(11) NOT NULL,
  `expirydate` date NOT NULL,
  `unitprice` int(11) NOT NULL,
  `totalprice` int(11) NOT NULL,
  `totalamt` int(11) NOT NULL,
  `paidamt` int(11) NOT NULL,
  `outbal` int(11) NOT NULL,
  `pricetype` text NOT NULL,
  `saleref` text NOT NULL,
  `salesdate` text NOT NULL,
  `paymethod` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

INSERT INTO `sales` VALUES ("1","ST101165293","JAYBISCO PHARMACY","EMZOR paracetamol Tab By 96","100","2018-09-20","210","21000","129420","129420","0","wholesale","ugo","2018-09-06","Cash"),
("2","ST101165293","JAYBISCO PHARMACY","EMZOR Paracetamol Syrup 60ml","100","2018-09-20","106","10600","129420","129420","0","wholesale","ugo","2018-09-06","Cash"),
("3","ST101165293","JAYBISCO PHARMACY","EMZOLYN ADULT","60","2018-09-28","169","10140","129420","129420","0","wholesale","ugo","2018-09-06","Cash"),
("4","ST101165293","JAYBISCO PHARMACY","EMTRIM TAB (Blister) 10 X 100","10","2018-09-20","4380","43800","129420","129420","0","wholesale","ugo","2018-09-06","Cash"),
("5","ST101165293","JAYBISCO PHARMACY","Em-Vit-C TAB (W) BY 100","100","2018-09-20","175","17500","129420","129420","0","wholesale","ugo","2018-09-06","Cash"),
("6","ST101165293","JAYBISCO PHARMACY","EM-VIT-C TAB (W) BY 1000","24","2018-09-20","725","17400","129420","129420","0","wholesale","ugo","2018-09-06","Cash"),
("7","ST101165293","JAYBISCO PHARMACY","NEUROGESIC OINTMENT S/S","10","2018-09-13","385","3850","129420","129420","0","wholesale","ugo","2018-09-06","Cash"),
("8","ST101165293","JAYBISCO PHARMACY","MALDOX TAB 1 x 3","57","2018-09-20","90","5130","129420","129420","0","wholesale","ugo","2018-09-06","Cash"),
("9","PP00002","GOD\'S CARE PHARMACY","Em-Vit-C TAB (C) BY 1000","24","2018-09-20","755","18120","56960","56960","0","wholesale","ugo","2018-09-06","Cash"),
("10","PP00002","GOD\'S CARE PHARMACY","Augumentin Tab 625mg","10","2018-09-20","2685","26850","56960","56960","0","wholesale","ugo","2018-09-06","Cash"),
("11","PP00002","GOD\'S CARE PHARMACY","AMPICLOX Caps Beecham 500mg","2","2018-09-20","5995","11990","56960","56960","0","wholesale","ugo","2018-09-06","Cash"),
("12","PP00003","LOVIFO PHARMACY","ASTYMIN SYRUP 200ml","5","2018-09-20","1080","5400","25080","25080","0","wholesale","ugo","2018-09-06","Cash"),
("13","PP00003","LOVIFO PHARMACY","ASTYFER SYRUP 200ml","5","2018-09-20","1080","5400","25080","25080","0","wholesale","ugo","2018-09-06","Cash"),
("14","PP00003","LOVIFO PHARMACY","EMMOX SUSPENSION","10","2018-09-20","206","2060","25080","25080","0","wholesale","ugo","2018-09-06","Cash"),
("15","PP00003","LOVIFO PHARMACY","EMTRIM SYRUP 50ml","10","2018-09-13","145","1450","25080","25080","0","wholesale","ugo","2018-09-06","Cash"),
("16","PP00003","LOVIFO PHARMACY","EMZOR Paracetamol Syrup 60ml","5","2018-09-20","106","530","25080","25080","0","wholesale","ugo","2018-09-06","Cash"),
("17","PP00003","LOVIFO PHARMACY","EMZOR paracetamol DROP","5","2018-09-20","130","650","25080","25080","0","wholesale","ugo","2018-09-06","Cash"),
("18","PP00003","LOVIFO PHARMACY","AMPICLOX SYRUP 250mg/5ml","2","2018-09-20","1065","2130","25080","25080","0","wholesale","ugo","2018-09-06","Cash"),
("19","PP00003","LOVIFO PHARMACY","Ciprotab Tab by 14","2","2018-09-20","1140","2280","25080","25080","0","wholesale","ugo","2018-09-06","Cash"),
("20","PP00003","LOVIFO PHARMACY","Ciprotab Tab 500mg By 10","5","2018-09-20","880","4400","25080","25080","0","wholesale","ugo","2018-09-06","Cash"),
("21","PP00003","LOVIFO PHARMACY","EMZOLYN CHILD","5","2018-09-20","156","780","25080","25080","0","wholesale","ugo","2018-09-06","Cash"),
("22","PP00004","ewere","EMZOR paracetamol Tab By 96","12","2018-09-30","210","2520","2520","0","2520","wholesale","pricepoint","2018-09-29","Credit");



DROP TABLE IF EXISTS `stock`;

CREATE TABLE `stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `productname` text NOT NULL,
  `expirydate` date NOT NULL,
  `stockbought` int(11) NOT NULL,
  `stocksold` int(11) NOT NULL,
  `stockremain` int(11) NOT NULL,
  `entry_date` date NOT NULL,
  `entries` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

INSERT INTO `stock` VALUES ("1","EMZOLYN ADULT","2018-09-28","60","60","0","2018-09-06","1"),
("2","EM-VIT-C TAB (W) BY 1000","2018-09-20","24","24","0","2018-09-06","1"),
("3","EMZOR Paracetamol Syrup 60ml","2018-09-20","105","105","0","2018-09-06","2"),
("4","EMTRIM TAB (Blister) 10 X 100","2018-09-20","10","10","0","2018-09-06","1"),
("5","Em-Vit-C TAB (W) BY 100","2018-09-20","100","100","0","2018-09-06","1"),
("6","NEUROGESIC OINTMENT S/S","2018-09-13","10","10","0","2018-09-06","1"),
("7","MALDOX TAB 1 x 3","2018-09-20","57","57","0","2018-09-06","1"),
("8","EMZOR paracetamol Tab By 96","2018-09-20","100","100","0","2018-09-06","1"),
("9","Em-Vit-C TAB (C) BY 1000","2018-09-20","100","24","76","2018-09-06","1"),
("10","Augumentin Tab 625mg","2018-09-20","10","10","0","2018-09-06","1"),
("11","AMPICLOX Caps Beecham 500mg","2018-09-20","2","2","0","2018-09-06","1"),
("12","ASTYMIN SYRUP 200ml","2018-09-20","5","5","0","2018-09-06","1"),
("13","ASTYFER SYRUP 200ml","2018-09-20","5","5","0","2018-09-06","1"),
("14","EMMOX SUSPENSION","2018-09-20","10","10","0","2018-09-06","1"),
("15","EMTRIM SYRUP 50ml","2018-09-13","10","10","0","2018-09-06","1"),
("16","EMZOR paracetamol DROP","2018-09-20","5","5","0","2018-09-06","1"),
("17","AMPICLOX SYRUP 250mg/5ml","2018-09-20","2","2","0","2018-09-06","1"),
("18","Ciprotab Tab by 14","2018-09-20","2","2","0","2018-09-06","1"),
("19","Ciprotab Tab 500mg By 10","2018-09-20","5","5","0","2018-09-06","1"),
("20","EMZOLYN CHILD","2018-09-20","5","5","0","2018-09-06","1"),
("21","EMZOR paracetamol Tab By 96","2018-09-30","32","12","20","2018-09-29","1");



DROP TABLE IF EXISTS `stockentry`;

CREATE TABLE `stockentry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entry_date` date NOT NULL,
  `product` text NOT NULL,
  `stockno` int(11) NOT NULL,
  `byadmin` text NOT NULL,
  `stockexpiry_date` date NOT NULL,
  `stocktype` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

INSERT INTO `stockentry` VALUES ("1","2018-09-06","EMZOLYN ADULT","60","ugo","2018-09-28","new"),
("2","2018-09-06","EM-VIT-C TAB (W) BY 1000","24","ugo","2018-09-20","new"),
("3","2018-09-06","EMZOR Paracetamol Syrup 60ml","100","ugo","2018-09-20","new"),
("4","2018-09-06","EMTRIM TAB (Blister) 10 X 100","10","ugo","2018-09-20","new"),
("5","2018-09-06","Em-Vit-C TAB (W) BY 100","100","ugo","2018-09-20","new"),
("6","2018-09-06","NEUROGESIC OINTMENT S/S","10","ugo","2018-09-13","new"),
("7","2018-09-06","MALDOX TAB 1 x 3","57","ugo","2018-09-20","new"),
("8","2018-09-06","EMZOR paracetamol Tab By 96","100","ugo","2018-09-20","new"),
("9","2018-09-06","Em-Vit-C TAB (C) BY 1000","100","ugo","2018-09-20","new"),
("10","2018-09-06","Augumentin Tab 625mg","10","ugo","2018-09-20","new"),
("11","2018-09-06","AMPICLOX Caps Beecham 500mg","2","ugo","2018-09-20","new"),
("12","2018-09-06","ASTYMIN SYRUP 200ml","5","ugo","2018-09-20","new"),
("13","2018-09-06","ASTYFER SYRUP 200ml","5","ugo","2018-09-20","new"),
("14","2018-09-06","EMMOX SUSPENSION","10","ugo","2018-09-20","new"),
("15","2018-09-06","EMTRIM SYRUP 50ml","10","ugo","2018-09-13","new"),
("16","2018-09-06","EMZOR Paracetamol Syrup 60ml","5","ugo","2018-09-20","new"),
("17","2018-09-06","EMZOR paracetamol DROP","5","ugo","2018-09-20","new"),
("18","2018-09-06","AMPICLOX SYRUP 250mg/5ml","2","ugo","2018-09-20","new"),
("19","2018-09-06","Ciprotab Tab by 14","2","ugo","2018-09-20","new"),
("20","2018-09-06","Ciprotab Tab 500mg By 10","5","ugo","2018-09-20","new"),
("21","2018-09-06","EMZOLYN CHILD","5","ugo","2018-09-20","new"),
("22","2018-09-29","EMZOR paracetamol Tab By 96","32","pricepoint","2018-09-30","new");



DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `category` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `users` VALUES ("1","pricepoint","$2y$11$63e1fdaef6a40ce75a786OdZikf6nP1PzXEcApnqU8DNwlFjRspti","admin"),
("2","jennifer","$2y$11$4a69fd31cc9049b35d163ejd74.e5BW5ShM3.kyAZ7Ym9IAcI.ZlG","user"),
("3","joyce","$2y$11$6605600a19c2900c5a492OkKED8aCoJL9ULRN4/QGR1puIYHkHDuq","user"),
("4","jenny","$2y$11$e65aaa2b2d2f5cfbdc7dbu7evbtEf9dTuCFvjHcj.kpTXgLfRtMzu","admin");



DROP TABLE IF EXISTS `users_session`;

CREATE TABLE `users_session` (
  `session_log` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `user_role` varchar(20) NOT NULL,
  `log_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `log_off` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `logged_out` int(11) NOT NULL,
  `duration` time NOT NULL,
  PRIMARY KEY (`session_log`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `users_session` VALUES ("1","pricepoint","admin","2018-09-29 04:11:28","0000-00-00 00:00:00","0","00:00:00");
